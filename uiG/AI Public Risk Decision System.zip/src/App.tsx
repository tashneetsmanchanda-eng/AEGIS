import { useState } from 'react';
import { FateWheel } from './components/FateWheel';
import { SystemDashboard } from './components/SystemDashboard';
import { EnvironmentPanel } from './components/EnvironmentPanel';
import { AIAgent } from './components/AIAgent';
import { CascadeView } from './components/CascadeView';
import { SystemTransition } from './components/transitions/SystemTransition';

export type SystemType = 
  | 'flood' 
  | 'cyclone' 
  | 'tsunami' 
  | 'respiratory' 
  | 'diarrhea' 
  | 'cholera' 
  | 'hepatitis' 
  | 'leptospirosis';

export interface LocationData {
  mode: 'city' | 'global' | 'custom';
  city?: string;
  state?: string;
  continent?: string;
  latitude?: number;
  longitude?: number;
}

export default function App() {
  const [selectedSystem, setSelectedSystem] = useState<SystemType | null>(null);
  const [location, setLocation] = useState<LocationData>({
    mode: 'city',
    city: 'Mumbai',
    state: 'Maharashtra'
  });
  const [showCascade, setShowCascade] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleSystemClick = (system: SystemType) => {
    setIsTransitioning(true);
    setTimeout(() => {
      setSelectedSystem(system);
      setIsTransitioning(false);
    }, 4000);
  };

  const handleBackToWheel = () => {
    setSelectedSystem(null);
  };

  const handleCascadeClick = () => {
    setShowCascade(true);
  };

  const handleCloseCascade = () => {
    setShowCascade(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 py-6 px-8 bg-slate-950/50 backdrop-blur-sm border-b border-slate-800/50">
        <h1 className="text-center tracking-[0.25em] uppercase">
          AEGIS — AI Public Risk Decision System
        </h1>
      </header>

      {/* Main Content */}
      <main className="pt-24 pb-8 px-8 min-h-screen">
        {isTransitioning && selectedSystem && (
          <SystemTransition system={selectedSystem} />
        )}

        {!selectedSystem && !isTransitioning ? (
          <div className="max-w-7xl mx-auto">
            <FateWheel 
              onSystemClick={handleSystemClick}
              location={location}
            />
          </div>
        ) : selectedSystem && !isTransitioning ? (
          <div className="max-w-7xl mx-auto">
            <SystemDashboard 
              system={selectedSystem}
              location={location}
              onBack={handleBackToWheel}
              onCascadeClick={handleCascadeClick}
            />
          </div>
        ) : null}
      </main>

      {/* Side Panels */}
      {!isTransitioning && (
        <>
          <EnvironmentPanel 
            location={location}
            onLocationChange={setLocation}
          />
          <AIAgent 
            selectedSystem={selectedSystem}
            location={location}
          />
        </>
      )}

      {/* Cascade View Overlay */}
      {showCascade && selectedSystem && (
        <CascadeView 
          system={selectedSystem}
          location={location}
          onClose={handleCloseCascade}
        />
      )}
    </div>
  );
}