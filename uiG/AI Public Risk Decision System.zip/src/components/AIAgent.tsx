import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Send, X } from 'lucide-react';
import type { SystemType, LocationData } from '../App';

interface AIAgentProps {
  selectedSystem: SystemType | null;
  location: LocationData;
}

interface Message {
  id: string;
  type: 'user' | 'agent';
  content: string;
  timestamp: Date;
}

const SYSTEM_CONTEXT = {
  flood: 'flood risk assessment',
  cyclone: 'cyclone preparedness',
  tsunami: 'tsunami alert protocols',
  respiratory: 'respiratory disease monitoring',
  diarrhea: 'diarrheal disease prevention',
  cholera: 'cholera outbreak management',
  hepatitis: 'hepatitis surveillance',
  leptospirosis: 'leptospirosis risk mitigation'
};

export function AIAgent({ selectedSystem, location }: AIAgentProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'agent',
      content: 'I\'m CHESEAL, your Decision Explanation & Scenario Analyst. I can explain why decisions were made and explore "what if" scenarios. I never override system decisions or recommend actions—I only explain.',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    // Generate AI response
    setTimeout(() => {
      const response = generateResponse(inputValue, selectedSystem, location);
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'agent',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, agentMessage]);
    }, 800);

    setInputValue('');
  };

  const generateResponse = (query: string, system: SystemType | null, loc: LocationData): string => {
    const lowerQuery = query.toLowerCase();

    // Context-aware responses
    if (lowerQuery.includes('why')) {
      if (system === 'flood') {
        return `The no-evacuation decision for ${loc.city || loc.continent} is based on rainfall anomaly analysis (+43%), stable river levels, and adequate infrastructure capacity. Historical flood patterns show low correlation with current conditions.`;
      } else if (system === 'cyclone') {
        return `Evacuation is required due to forecasted wind speeds of 145 km/h, expected storm surge of 3.2m, and 87% historical cyclone path overlap. Coastal infrastructure is particularly vulnerable.`;
      } else if (system === 'respiratory') {
        return `The public health advisory is triggered by AQI stress levels 62% above safe thresholds, trending respiratory admissions, and 2.3M vulnerable population affected by worsening weather conditions.`;
      }
      return 'The decision is based on multi-model analysis, historical patterns, real-time data feeds, and threshold-based risk criteria.';
    }

    if (lowerQuery.includes('what if') || lowerQuery.includes('scenario')) {
      return 'Scenario analysis is available through the Cascade feature. It projects multi-order consequences across economic, health, and infrastructure domains. Click "View Cascade" to explore alternative outcomes.';
    }

    if (lowerQuery.includes('confidence') || lowerQuery.includes('certain')) {
      return 'Decision confidence is calculated through ensemble model agreement, data quality scores, historical validation accuracy, and uncertainty quantification. Values above 90% indicate high-confidence actionable decisions.';
    }

    if (lowerQuery.includes('update') || lowerQuery.includes('refresh')) {
      return 'Risk assessments are continuously updated. The next scheduled review depends on system criticality: 6 hours for critical threats, 24-48 hours for moderate risks, and 72+ hours for low-level monitoring.';
    }

    if (lowerQuery.includes('data') || lowerQuery.includes('source')) {
      return 'AEGIS integrates satellite imagery, weather station networks, hospital admission records, water quality sensors, seismic monitoring, and population density mapping. All sources undergo validation before influencing decisions.';
    }

    if (lowerQuery.includes('evacuation')) {
      return 'Evacuation decisions are triggered when risk thresholds exceed 90% confidence and consequence models predict significant casualties. Factors include population density, infrastructure vulnerability, and available response time.';
    }

    // Default contextual response
    if (system) {
      return `I'm currently analyzing ${SYSTEM_CONTEXT[system]} for ${loc.city || loc.continent || 'the selected region'}. Ask me about specific decision factors, confidence levels, or alternative scenarios.`;
    }

    return 'I can help explain any risk assessment. Select a system from the wheel or ask about decision methodology, data sources, or consequence projections.';
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-50 bg-gradient-to-br from-cyan-600 to-blue-600 rounded-full p-4 shadow-2xl hover:shadow-cyan-500/50 transition-all"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 text-white" />
        )}
      </motion.button>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-24 right-8 z-40 w-96 h-[500px] bg-slate-900/95 backdrop-blur-sm border border-slate-800 rounded-2xl shadow-2xl flex flex-col"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 20 }}
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm tracking-[0.2em] uppercase text-cyan-400">
                CHESEAL
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Decision Explanation & Scenario Analyst
              </p>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map(message => (
                <motion.div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.type === 'user'
                        ? 'bg-cyan-600/20 border border-cyan-500/30 text-cyan-100'
                        : 'bg-slate-800/50 border border-slate-700/50 text-slate-200'
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    <p className="text-xs text-slate-500 mt-2">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-slate-800">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask about decisions, scenarios..."
                  className="flex-1 bg-slate-800/50 border border-slate-700/50 rounded-xl px-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
                />
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim()}
                  className="bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-xl p-2 transition-colors"
                >
                  <Send className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}