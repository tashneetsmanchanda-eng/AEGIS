import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { X } from 'lucide-react';
import type { SystemType, LocationData } from '../App';

interface CascadeViewProps {
  system: SystemType;
  location: LocationData;
  onClose: () => void;
}

const CASCADE_DATA = {
  flood: {
    title: 'Flood Cascade Analysis',
    consequences: [
      {
        order: 'Immediate (0-7 days)',
        impacts: [
          'Infrastructure damage: Roads, bridges submerged',
          'Displacement: 45,000-68,000 people',
          'Water contamination: Municipal supply compromised'
        ]
      },
      {
        order: 'Medium (2-6 weeks)',
        impacts: [
          'Supply chain disruption: Food, medicine shortages',
          'Disease outbreak risk: Waterborne infections +240%',
          'Economic halt: ₹120-180 Cr daily losses'
        ]
      },
      {
        order: 'Long-term (6+ months)',
        impacts: [
          'Long-term displacement: Housing crisis',
          'Agricultural collapse: Crop yield -60%',
          'Social instability: Resource conflicts, migration'
        ]
      }
    ]
  },
  cyclone: {
    title: 'Cyclone Cascade Analysis',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Structural damage: 12,000+ buildings at risk',
          'Power grid failure: 2.5M people affected',
          'Immediate casualties: 340-580 projected'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Communication breakdown: Emergency response delayed',
          'Healthcare system overwhelm: Trauma surge',
          'Economic shock: ₹1,200+ Cr property damage'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Reconstruction burden: 18-24 month recovery',
          'Insurance crisis: Premium spikes, coverage gaps',
          'Climate migration: Permanent population shifts'
        ]
      }
    ]
  },
  tsunami: {
    title: 'Tsunami Cascade Analysis',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Coastal inundation: 5-8 km inland penetration',
          'Mass casualties: 2,000-5,000 in high-risk zones',
          'Port infrastructure destroyed: Trade halt'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Fishing industry collapse: Livelihoods lost',
          'Salinization: Agricultural land degraded',
          'Tourism sector devastation: ₹800+ Cr annual loss'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Ecosystem disruption: Marine biodiversity impact',
          'Cultural heritage loss: Coastal sites destroyed',
          'Generational trauma: Psychological health crisis'
        ]
      }
    ]
  },
  respiratory: {
    title: 'Respiratory Disease Cascade',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Hospital admissions surge: +35% capacity strain',
          'Vulnerable populations: 2.3M at heightened risk',
          'Productivity loss: ₹85-120 Cr economic impact'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Healthcare worker burnout: System fragility',
          'Chronic condition worsening: Long-term burden',
          'School closures: Education disruption'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Public health policy shift: Emission controls',
          'Real estate valuation changes: Air quality premium',
          'Social inequality deepening: Health disparities'
        ]
      }
    ]
  },
  diarrhea: {
    title: 'Diarrheal Disease Cascade',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Case surge: +22% above baseline',
          'Child mortality risk: Under-5 vulnerability',
          'Water infrastructure stress: Treatment capacity'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Malnutrition increase: Growth stunting',
          'Healthcare costs: ₹28-40 Cr treatment burden',
          'School absenteeism: Education quality decline'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Developmental delays: Cognitive impacts',
          'Workforce productivity: Future human capital loss',
          'Sanitation investment: Infrastructure overhaul needs'
        ]
      }
    ]
  },
  cholera: {
    title: 'Cholera Outbreak Cascade',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Rapid spread: 180-340 cases in cluster zones',
          'Quarantine measures: Mobility restrictions',
          'Water source contamination: Supply shutdown'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Economic activity halt: ₹65-95 Cr response costs',
          'Panic and migration: Population displacement',
          'Healthcare system overwhelm: Resource depletion'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Endemic establishment risk: Recurring outbreaks',
          'Public trust erosion: Government response critique',
          'International trade impact: Travel advisories'
        ]
      }
    ]
  },
  hepatitis: {
    title: 'Hepatitis Risk Cascade',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Case increase: +12% above baseline',
          'Blood supply concerns: Screening intensification',
          'Food service disruption: Safety inspections'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Chronic liver disease burden: Long-term care needs',
          'Healthcare costs: ₹35-50 Cr treatment expenses',
          'Vaccination campaign: Public health mobilization'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Liver transplant demand: Organ shortage crisis',
          'Food industry regulation: Safety standard evolution',
          'Health insurance impacts: Premium adjustments'
        ]
      }
    ]
  },
  leptospirosis: {
    title: 'Leptospirosis Outbreak Cascade',
    consequences: [
      {
        order: 'First Order',
        impacts: [
          'Infection surge: +28% in high-risk occupations',
          'Rainfall correlation: Flooding exposure events',
          'Rodent population spike: Environmental conditions'
        ]
      },
      {
        order: 'Second Order',
        impacts: [
          'Occupational safety crisis: Worker protections',
          'Economic impact: ₹45-70 Cr productivity loss',
          'Urban sanitation failure: Waste management stress'
        ]
      },
      {
        order: 'Third Order',
        impacts: [
          'Vector control policy: Integrated pest management',
          'Climate adaptation needs: Rainfall pattern changes',
          'Zoonotic disease awareness: One Health approach'
        ]
      }
    ]
  }
};

export function CascadeView({ system, location, onClose }: CascadeViewProps) {
  const [phase, setPhase] = useState<'entering' | 'display'>('entering');
  const data = CASCADE_DATA[system];

  useEffect(() => {
    // Entering phase with butterflies
    const enterTimer = setTimeout(() => {
      setPhase('display');
    }, 1200);

    return () => {
      clearTimeout(enterTimer);
    };
  }, []);

  // Generate butterflies
  const butterflies = Array.from({ length: 12 }, (_, i) => ({
    id: i,
    delay: i * 0.1,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 20 + Math.random() * 15,
    duration: 2 + Math.random() * 2
  }));

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-purple-950/90 via-slate-900/90 to-teal-950/90 backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      />

      {/* Butterflies - Entering Phase */}
      {phase === 'entering' && (
        <div className="absolute inset-0 overflow-hidden">
          {butterflies.map(butterfly => (
            <motion.div
              key={butterfly.id}
              className="absolute"
              initial={{ 
                x: `${butterfly.x}vw`, 
                y: '-10vh',
                opacity: 0 
              }}
              animate={{ 
                x: [`${butterfly.x}vw`, `${butterfly.x + (Math.random() - 0.5) * 20}vw`],
                y: [`-10vh`, `${butterfly.y}vh`, `${butterfly.y + 20}vh`],
                opacity: [0, 1, 1, 0],
                rotate: [0, 360]
              }}
              transition={{ 
                duration: butterfly.duration,
                delay: butterfly.delay,
                ease: 'easeInOut'
              }}
              style={{
                filter: 'drop-shadow(0 0 10px rgba(167, 139, 250, 0.6))'
              }}
            >
              <svg
                width={butterfly.size}
                height={butterfly.size}
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M12 4C10 4 8 6 8 8C8 8 6 8 4 10C2 12 2 14 4 16C6 18 8 18 8 18C8 20 10 22 12 22C14 22 16 20 16 18C16 18 18 18 20 16C22 14 22 12 20 10C18 8 16 8 16 8C16 6 14 4 12 4Z"
                  fill="url(#gradient)"
                  opacity="0.8"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#a78bfa" />
                    <stop offset="100%" stopColor="#2dd4bf" />
                  </linearGradient>
                </defs>
              </svg>
            </motion.div>
          ))}
        </div>
      )}

      {/* Content - Display Phase */}
      {phase === 'display' && (
        <motion.div
          className="relative max-w-5xl w-full mx-8"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          {/* Close Button */}
          <motion.button
            onClick={onClose}
            className="absolute -top-4 -right-4 z-10 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-full p-3 transition-colors"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <X className="w-6 h-6 text-slate-300" />
          </motion.button>

          <div className="bg-slate-900/50 backdrop-blur-md border border-indigo-500/30 rounded-3xl p-8 shadow-2xl">
            <motion.h2
              className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Consequence Projection Engine
            </motion.h2>

            <motion.h3
              className="text-xl text-center text-slate-300 mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {data.title}
            </motion.h3>

            <p className="text-center text-sm text-slate-400 mb-8">
              Location: {location.city || location.continent || 'Custom Region'}
            </p>

            <div className="grid grid-cols-3 gap-6">
              {data.consequences.map((consequence, index) => (
                <motion.div
                  key={consequence.order}
                  className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.15 }}
                >
                  <h4 className="text-sm tracking-[0.2em] uppercase text-purple-400 mb-4">
                    {consequence.order}
                  </h4>
                  <ul className="space-y-3">
                    {consequence.impacts.map((impact, i) => (
                      <motion.li
                        key={i}
                        className="text-sm text-slate-300 leading-relaxed flex items-start gap-2"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 + index * 0.15 + i * 0.1 }}
                      >
                        <span className="text-teal-400 mt-1">•</span>
                        <span>{impact}</span>
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}