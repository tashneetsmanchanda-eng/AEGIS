import { useState } from 'react';
import { motion } from 'motion/react';
import { Droplets, Wind, Waves, Activity, Droplet, Zap, AlertCircle, Bug } from 'lucide-react';
import type { SystemType, LocationData } from '../App';

interface FateWheelProps {
  onSystemClick: (system: SystemType) => void;
  location: LocationData;
}

const SYSTEMS = [
  { id: 'flood' as SystemType, label: 'Flood', icon: Droplets, color: '#3b82f6' },
  { id: 'cyclone' as SystemType, label: 'Cyclone', icon: Wind, color: '#8b5cf6' },
  { id: 'tsunami' as SystemType, label: 'Tsunami', icon: Waves, color: '#06b6d4' },
  { id: 'respiratory' as SystemType, label: 'Respiratory', icon: Activity, color: '#f59e0b' },
  { id: 'diarrhea' as SystemType, label: 'Diarrhea', icon: Droplet, color: '#10b981' },
  { id: 'cholera' as SystemType, label: 'Cholera', icon: Zap, color: '#14b8a6' },
  { id: 'hepatitis' as SystemType, label: 'Hepatitis', icon: AlertCircle, color: '#ef4444' },
  { id: 'leptospirosis' as SystemType, label: 'Leptospirosis', icon: Bug, color: '#6366f1' },
];

export function FateWheel({ onSystemClick, location }: FateWheelProps) {
  const [hoveredSystem, setHoveredSystem] = useState<SystemType | null>(null);

  const radius = 280;
  const centerX = 400;
  const centerY = 300;

  return (
    <div className="relative flex items-center justify-center min-h-[700px]">
      {/* Rotating Container */}
      <motion.div
        className="relative"
        style={{ width: centerX * 2, height: centerY * 2 }}
        animate={{ rotate: 360 }}
        transition={{
          duration: 100,
          ease: 'linear',
          repeat: Infinity
        }}
      >
        {/* Outer Circle */}
        <svg 
          className="absolute inset-0 w-full h-full"
          viewBox={`0 0 ${centerX * 2} ${centerY * 2}`}
        >
          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="none"
            stroke="rgba(148, 163, 184, 0.2)"
            strokeWidth="2"
            strokeDasharray="8 8"
          />
        </svg>

        {/* System Nodes */}
        {SYSTEMS.map((system, index) => {
          const angle = (index * 360) / SYSTEMS.length - 90;
          const radian = (angle * Math.PI) / 180;
          const x = centerX + radius * Math.cos(radian);
          const y = centerY + radius * Math.sin(radian);

          const Icon = system.icon;
          const isHovered = hoveredSystem === system.id;

          return (
            <div key={system.id}>
              {/* Radial Line */}
              <svg 
                className="absolute inset-0 w-full h-full pointer-events-none"
                viewBox={`0 0 ${centerX * 2} ${centerY * 2}`}
              >
                <line
                  x1={centerX}
                  y1={centerY}
                  x2={x}
                  y2={y}
                  stroke={isHovered ? system.color : 'rgba(148, 163, 184, 0.15)'}
                  strokeWidth={isHovered ? '2' : '1'}
                  className="transition-all duration-300"
                />
                
                {/* Energy Particle on Hover */}
                {isHovered && (
                  <motion.circle
                    cx={centerX}
                    cy={centerY}
                    r="4"
                    fill={system.color}
                    initial={{ cx: centerX, cy: centerY }}
                    animate={{
                      cx: [centerX, x],
                      cy: [centerY, y],
                    }}
                    transition={{
                      duration: 1.5,
                      ease: 'linear',
                      repeat: Infinity,
                    }}
                    style={{
                      filter: `drop-shadow(0 0 8px ${system.color})`
                    }}
                  />
                )}
              </svg>

              {/* Node */}
              <motion.button
                className="absolute rounded-full p-6 backdrop-blur-sm border-2 transition-all cursor-pointer"
                style={{
                  left: x - 32,
                  top: y - 32,
                  borderColor: isHovered ? system.color : 'rgba(148, 163, 184, 0.3)',
                  backgroundColor: isHovered 
                    ? `${system.color}20` 
                    : 'rgba(15, 23, 42, 0.5)',
                  boxShadow: isHovered 
                    ? `0 0 30px ${system.color}40` 
                    : 'none',
                }}
                onMouseEnter={() => setHoveredSystem(system.id)}
                onMouseLeave={() => setHoveredSystem(null)}
                onClick={() => onSystemClick(system.id)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                animate={{ rotate: -360 }}
                transition={{
                  rotate: {
                    duration: 100,
                    ease: 'linear',
                    repeat: Infinity
                  }
                }}
              >
                <Icon 
                  className="w-8 h-8" 
                  style={{ color: isHovered ? system.color : '#94a3b8' }}
                />
              </motion.button>

              {/* Label */}
              <motion.div
                className="absolute text-sm font-medium pointer-events-none transition-opacity duration-300"
                style={{
                  left: x + (Math.cos(radian) * 60) - 40,
                  top: y + (Math.sin(radian) * 60) - 10,
                  color: isHovered ? system.color : '#94a3b8',
                  textAlign: 'center',
                  width: '80px',
                  opacity: isHovered ? 1 : 0.7
                }}
                animate={{ rotate: -360 }}
                transition={{
                  duration: 100,
                  ease: 'linear',
                  repeat: Infinity
                }}
              >
                {system.label}
              </motion.div>
            </div>
          );
        })}

        {/* Center Point */}
        <div 
          className="absolute rounded-full bg-slate-800 border-2 border-slate-600"
          style={{
            left: centerX - 8,
            top: centerY - 8,
            width: 16,
            height: 16,
          }}
        />
      </motion.div>

      {/* Instructions */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center">
        <p className="text-slate-400 text-sm">
          Hover over systems to preview | Click to analyze
        </p>
      </div>
    </div>
  );
}