import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, AlertTriangle, CheckCircle, X } from 'lucide-react';
import type { SystemType, LocationData } from '../App';

interface SystemDashboardProps {
  system: SystemType;
  location: LocationData;
  onBack: () => void;
  onCascadeClick: () => void;
}

const SYSTEM_DATA = {
  flood: {
    name: 'Flood Risk',
    decisionConfidence: 78,
    action: 'NO EVACUATION — MONITOR & PREPARE',
    validityWindow: '72 hours',
    riskLevel: 'MODERATE',
    activeModels: 3,
    outcomes: [
      'No Evacuation Required',
      'Emergency Services on Standby',
      'Public Advisory Issued'
    ],
    primaryDrivers: [
      'Rainfall anomaly: +43%',
      'River levels stable',
      'Infrastructure capacity adequate'
    ],
    secondaryDrivers: [
      'Drainage stress minimal',
      'Population density manageable'
    ],
    alternativeAction: 'Immediate Evacuation',
    rejectedBecause: [
      'River capacity within safe margins',
      'Infrastructure resilient to current levels',
      'Economic disruption unnecessary'
    ],
    costOfInaction: '+18% hospital admissions | ₹42–55 Cr economic loss',
    nextReview: '24 hours'
  },
  cyclone: {
    name: 'Cyclone Risk',
    decisionConfidence: 92,
    action: 'EVACUATION REQUIRED WITHIN 24 HOURS',
    validityWindow: '48 hours',
    riskLevel: 'CRITICAL',
    activeModels: 4,
    outcomes: [
      'Immediate Evacuation to Shelters',
      'Port Operations Suspended',
      'Emergency Response Activated'
    ],
    primaryDrivers: [
      'Wind speed forecast: 145 km/h',
      'Storm surge: 3.2m expected',
      'Historical cyclone path overlap: 87%'
    ],
    secondaryDrivers: [
      'Coastal infrastructure vulnerable',
      'Population density in impact zone'
    ],
    alternativeAction: 'Delay Advisory',
    rejectedBecause: [
      'Casualty projection: 340-580 lives at risk',
      'Property damage: ₹1,200+ Cr irreversible',
      'Time window insufficient for safe delay'
    ],
    costOfInaction: '340–580 casualties | ₹1,200+ Cr property damage',
    nextReview: '6 hours'
  },
  tsunami: {
    name: 'Tsunami Risk',
    decisionConfidence: 67,
    action: 'NO EVACUATION — MAINTAIN ALERT STATUS',
    validityWindow: '96 hours',
    riskLevel: 'LOW',
    activeModels: 2,
    outcomes: [
      'Coastal Alert System Active',
      'No Immediate Evacuation',
      'Monitoring Stations Updated'
    ],
    primaryDrivers: [
      'Seismic activity: Below threshold',
      'Offshore disturbance minimal',
      'Warning buoys show normal levels'
    ],
    secondaryDrivers: [
      'Tectonic plate stability confirmed',
      'Historical tsunami patterns absent'
    ],
    alternativeAction: 'Precautionary Evacuation',
    rejectedBecause: [
      'Seismic indicators do not warrant action',
      'False alarm economic cost: ₹180+ Cr',
      'Population fatigue risk'
    ],
    costOfInaction: 'Minimal immediate risk',
    nextReview: '48 hours'
  },
  respiratory: {
    name: 'Respiratory Disease Risk',
    decisionConfidence: 85,
    action: 'PUBLIC HEALTH ADVISORY — VULNERABLE GROUPS',
    validityWindow: '120 hours',
    riskLevel: 'ELEVATED',
    activeModels: 5,
    outcomes: [
      'Air Quality Alert Issued',
      'Hospital Capacity Expanded',
      'School Outdoor Activities Restricted'
    ],
    primaryDrivers: [
      'AQI stress: +62% above safe levels',
      'Respiratory admissions trending up',
      'Vulnerable population: 2.3M affected'
    ],
    secondaryDrivers: [
      'Weather conditions worsening air quality',
      'Industrial emission levels elevated'
    ],
    alternativeAction: 'Full Lockdown',
    rejectedBecause: [
      'Economic paralysis cost: ₹500+ Cr daily',
      'Health system stress manageable',
      'Targeted advisory sufficient'
    ],
    costOfInaction: '+35% respiratory admissions | ₹85–120 Cr healthcare costs',
    nextReview: '36 hours'
  },
  diarrhea: {
    name: 'Diarrheal Disease Risk',
    decisionConfidence: 73,
    action: 'NO EVACUATION — SANITATION PROTOCOLS ACTIVE',
    validityWindow: '72 hours',
    riskLevel: 'MODERATE',
    activeModels: 3,
    outcomes: [
      'Water Quality Testing Increased',
      'Public Hygiene Campaign Launched',
      'Medical Supplies Pre-positioned'
    ],
    primaryDrivers: [
      'Water contamination detected: 3 sites',
      'Seasonal outbreak pattern identified',
      'Sanitation infrastructure stable'
    ],
    secondaryDrivers: [
      'Hospital capacity sufficient',
      'Public awareness campaign active'
    ],
    alternativeAction: 'Water Supply Shutdown',
    rejectedBecause: [
      'Contamination isolated to specific sites',
      'Alternative sources available',
      'Supply shutdown creates greater crisis'
    ],
    costOfInaction: '+22% cases | ₹28–40 Cr treatment costs',
    nextReview: '48 hours'
  },
  cholera: {
    name: 'Cholera Risk',
    decisionConfidence: 88,
    action: 'TARGETED INTERVENTION — HIGH-RISK ZONES',
    validityWindow: '96 hours',
    riskLevel: 'HIGH',
    activeModels: 4,
    outcomes: [
      'Vaccination Campaign Initiated',
      'Water Purification Units Deployed',
      'Quarantine Protocols Ready'
    ],
    primaryDrivers: [
      'Confirmed cases: 47 in cluster zones',
      'Water source contamination verified',
      'Population density risk factor high'
    ],
    secondaryDrivers: [
      'Rapid response teams mobilized',
      'Sanitation conditions degraded'
    ],
    alternativeAction: 'City-wide Quarantine',
    rejectedBecause: [
      'Outbreak contained to cluster zones',
      'Targeted intervention more effective',
      'City-wide quarantine economically devastating'
    ],
    costOfInaction: '180–340 cases | ₹65–95 Cr response costs',
    nextReview: '24 hours'
  },
  hepatitis: {
    name: 'Hepatitis Risk',
    decisionConfidence: 71,
    action: 'NO EVACUATION — SCREENING PROTOCOLS ACTIVE',
    validityWindow: '168 hours',
    riskLevel: 'MODERATE',
    activeModels: 3,
    outcomes: [
      'Blood Screening Enhanced',
      'Food Safety Inspections Increased',
      'Awareness Campaign Active'
    ],
    primaryDrivers: [
      'Viral load in water: Minimal',
      'Food safety compliance: 82%',
      'Vaccination coverage adequate'
    ],
    secondaryDrivers: [
      'No outbreak clusters detected',
      'Healthcare system prepared'
    ],
    alternativeAction: 'Mass Vaccination Campaign',
    rejectedBecause: [
      'Current vaccination coverage sufficient',
      'Cost-benefit ratio unfavorable',
      'Targeted screening more efficient'
    ],
    costOfInaction: '+12% cases | ₹35–50 Cr healthcare burden',
    nextReview: '72 hours'
  },
  leptospirosis: {
    name: 'Leptospirosis Risk',
    decisionConfidence: 81,
    action: 'PUBLIC ADVISORY — RAINFALL PRECAUTIONS',
    validityWindow: '96 hours',
    riskLevel: 'ELEVATED',
    activeModels: 4,
    outcomes: [
      'Rodent Control Measures Active',
      'Protective Equipment Distributed',
      'Medical Surveillance Enhanced'
    ],
    primaryDrivers: [
      'Heavy rainfall predicted: +65mm',
      'Rodent population density high',
      'Occupational exposure risk elevated'
    ],
    secondaryDrivers: [
      'Past outbreak correlation: 76%',
      'Sanitation infrastructure challenged'
    ],
    alternativeAction: 'Work Suspension Order',
    rejectedBecause: [
      'Infection growth +28% (48–72h) manageable',
      'Economic impact: ₹200+ Cr daily',
      'Protective measures sufficient'
    ],
    costOfInaction: '+28% infections | ₹45–70 Cr economic impact',
    nextReview: '48 hours'
  }
};

export function SystemDashboard({ system, location, onBack, onCascadeClick }: SystemDashboardProps) {
  const data = SYSTEM_DATA[system];
  const isCritical = data.decisionConfidence >= 90;

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors rounded-xl px-4 py-2 hover:bg-slate-800/50"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Overview
      </button>

      {/* System Decision Banner */}
      <motion.div
        className={`rounded-2xl p-8 border-2 ${
          isCritical 
            ? 'bg-red-950/30 border-red-500/50' 
            : 'bg-slate-800/50 border-slate-600/50'
        }`}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-sm tracking-[0.2em] uppercase text-slate-400 mb-2">
              System Decision
            </h2>
            <h3 className={`text-3xl font-bold ${isCritical ? 'text-red-400' : 'text-white'}`}>
              {data.action}
            </h3>
          </div>
          {isCritical && <AlertTriangle className="w-12 h-12 text-red-400" />}
        </div>

        <div className="grid grid-cols-3 gap-6 mb-4">
          <div>
            <p className="text-sm text-slate-400 mb-1">Decision Confidence</p>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-3 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full ${
                    data.decisionConfidence >= 90 
                      ? 'bg-red-500' 
                      : data.decisionConfidence >= 75 
                      ? 'bg-yellow-500' 
                      : 'bg-green-500'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${data.decisionConfidence}%` }}
                  transition={{ duration: 1, delay: 0.3 }}
                />
              </div>
              <span className="text-xl font-bold">{data.decisionConfidence}%</span>
            </div>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Decision Valid Until</p>
            <p className="text-xl font-bold">{data.validityWindow}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Next Re-evaluation</p>
            <p className="text-xl font-bold">{data.nextReview}</p>
          </div>
        </div>

        {/* Cost of Inaction */}
        <div className="pt-4 border-t border-slate-700/50">
          <p className="text-sm text-slate-400 mb-1">Cost of Inaction ({data.validityWindow})</p>
          <p className="text-lg font-medium text-orange-400">{data.costOfInaction}</p>
        </div>
      </motion.div>

      {/* Alternative Action Analysis - Trade-off Strip */}
      <motion.div
        className="rounded-2xl bg-slate-800/30 border border-slate-700/30 p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <h3 className="text-xs tracking-[0.2em] uppercase text-slate-500 mb-3">
          Alternative Action Analysis
        </h3>
        <div className="flex items-start gap-4">
          <X className="w-4 h-4 text-red-400/60 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-slate-400 mb-2">
              Option Considered: <span className="text-slate-300">{data.alternativeAction}</span>
            </p>
            <p className="text-xs text-slate-500 mb-2">Rejected Because:</p>
            <ul className="space-y-1">
              {data.rejectedBecause.map((reason, index) => (
                <li key={index} className="text-xs text-slate-400 flex items-start gap-2">
                  <span className="text-red-400/40">•</span>
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </motion.div>

      {/* Info Cards Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Risk Level */}
        <motion.div
          className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <p className="text-sm text-slate-400 mb-2">Risk Level</p>
          <p className={`text-2xl font-bold ${
            data.riskLevel === 'CRITICAL' ? 'text-red-400' :
            data.riskLevel === 'HIGH' ? 'text-orange-400' :
            data.riskLevel === 'ELEVATED' ? 'text-yellow-400' :
            data.riskLevel === 'MODERATE' ? 'text-blue-400' :
            'text-green-400'
          }`}>
            {data.riskLevel}
          </p>
        </motion.div>

        {/* Active Models */}
        <motion.div
          className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <p className="text-sm text-slate-400 mb-2">Active Models</p>
          <p className="text-2xl font-bold">{data.activeModels}</p>
          <p className="text-xs text-slate-500 mt-1">Credibility indicators</p>
        </motion.div>

        {/* Decision Outcome Summary */}
        <motion.div
          className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <p className="text-sm text-slate-400 mb-2">Decision Outcomes</p>
          <p className="text-2xl font-bold">{data.outcomes.length}</p>
          <p className="text-xs text-slate-500 mt-1">Actions initiated</p>
        </motion.div>
      </div>

      {/* Decision Outcome Block */}
      <motion.div
        className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <h3 className="text-sm tracking-[0.2em] uppercase text-slate-400 mb-4">
          Decision Outcome
        </h3>
        <div className="space-y-3">
          {data.outcomes.map((outcome, index) => (
            <motion.div
              key={index}
              className="flex items-center gap-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.6 + index * 0.1 }}
            >
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
              <span className="text-slate-200">{outcome}</span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Why This Decision - Ranked Signals */}
      <div className="grid grid-cols-2 gap-6">
        <motion.div
          className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <h3 className="text-xs tracking-[0.2em] uppercase text-slate-400 mb-4">
            Primary Drivers
          </h3>
          <ol className="space-y-3">
            {data.primaryDrivers.map((driver, index) => (
              <motion.li
                key={index}
                className="flex items-start gap-3 text-slate-200"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + index * 0.1 }}
              >
                <span className="text-cyan-400 font-bold flex-shrink-0">{index + 1}.</span>
                <span className="text-sm">{driver}</span>
              </motion.li>
            ))}
          </ol>
        </motion.div>

        <motion.div
          className="rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <h3 className="text-xs tracking-[0.2em] uppercase text-slate-400 mb-4">
            Secondary Drivers
          </h3>
          <ul className="space-y-3">
            {data.secondaryDrivers.map((driver, index) => (
              <motion.li
                key={index}
                className="flex items-start gap-3 text-slate-300"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + index * 0.1 }}
              >
                <span className="text-slate-500">•</span>
                <span className="text-sm">{driver}</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      </div>

      {/* Cascade Button */}
      <motion.button
        onClick={onCascadeClick}
        className="w-full rounded-2xl bg-gradient-to-br from-indigo-900/40 to-cyan-900/40 border border-indigo-500/30 p-8 hover:border-indigo-400/50 transition-all"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.9 }}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <h3 className="text-sm tracking-[0.2em] uppercase text-indigo-300 mb-2">
          View Cascade Analysis
        </h3>
        <p className="text-sm text-slate-400">
          Explore multi-order consequence projections
        </p>
      </motion.button>
    </div>
  );
}
