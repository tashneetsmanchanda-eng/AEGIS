import { motion } from 'motion/react';

export function CholeraTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-teal-950/40 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Clean to Infected Contrast - Left Side (Clean) */}
      <motion.div
        className="absolute left-0 top-0 bottom-0 w-1/2 bg-gradient-to-r from-cyan-900/30 to-transparent"
        initial={{ opacity: 1 }}
        animate={{ opacity: [1, 0.3] }}
        transition={{ duration: 3, ease: 'easeInOut' }}
      />

      {/* Right Side (Infected) */}
      <motion.div
        className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-teal-900/60 to-transparent"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 3, ease: 'easeInOut' }}
      />

      {/* Bio-luminescent Spread Effect */}
      {[...Array(20)].map((_, i) => {
        const angle = (i * 18) * Math.PI / 180;
        const radius = 150;
        
        return (
          <motion.div
            key={i}
            className="absolute w-4 h-4 rounded-full bg-teal-400"
            initial={{ 
              x: window.innerWidth / 2,
              y: window.innerHeight / 2,
              opacity: 0,
              scale: 0
            }}
            animate={{ 
              x: window.innerWidth / 2 + Math.cos(angle) * (radius + i * 30),
              y: window.innerHeight / 2 + Math.sin(angle) * (radius + i * 30),
              opacity: [0, 0.8, 0],
              scale: [0, 1.5, 0.5]
            }}
            transition={{ 
              duration: 3,
              delay: i * 0.1,
              ease: 'easeOut'
            }}
            style={{
              filter: 'blur(4px)',
              boxShadow: '0 0 20px rgba(20, 184, 166, 0.8)'
            }}
          />
        );
      })}

      {/* Spreading Circles */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute left-1/2 top-1/2 rounded-full border-2 border-teal-400/50"
          initial={{ 
            width: 0,
            height: 0,
            x: '-50%',
            y: '-50%',
            opacity: 0
          }}
          animate={{ 
            width: 800,
            height: 800,
            opacity: [0, 0.6, 0]
          }}
          transition={{ 
            duration: 4,
            delay: i * 0.8,
            ease: 'easeOut'
          }}
        />
      ))}

      {/* Clinical Terror - Pulsing Grid */}
      <motion.div
        className="absolute inset-0"
        style={{
          backgroundImage: 'linear-gradient(rgba(20, 184, 166, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(20, 184, 166, 0.1) 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.4, 0.2] }}
        transition={{ duration: 3 }}
      />

      {/* Bacterial Forms Floating */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-teal-500/40"
          style={{
            width: 20 + Math.random() * 30,
            height: 20 + Math.random() * 30
          }}
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: -50,
            opacity: 0.6
          }}
          animate={{ 
            x: Math.random() * window.innerWidth,
            y: window.innerHeight + 50,
            opacity: [0.6, 0.3, 0],
            rotate: 360
          }}
          transition={{ 
            duration: 5 + Math.random() * 3,
            delay: i * 0.3,
            ease: 'linear'
          }}
          style={{
            filter: 'blur(6px)'
          }}
        />
      ))}

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <h2 className="text-4xl font-bold text-teal-200 mb-2">Analyzing Cholera Risk</h2>
        <p className="text-teal-300">Bio-contamination spread modeling...</p>
      </motion.div>
    </div>
  );
}
