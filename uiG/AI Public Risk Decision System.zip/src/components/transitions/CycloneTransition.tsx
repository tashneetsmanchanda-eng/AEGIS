import { motion } from 'motion/react';

export function CycloneTransition() {
  return (
    <div className="absolute inset-0 bg-slate-950 overflow-hidden flex items-center justify-center">
      {/* Rotating Vortex */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, transparent 0%, rgba(139, 92, 246, 0.3) 50%, rgba(139, 92, 246, 0.6) 100%)'
        }}
        initial={{ rotate: 0, scale: 0.5 }}
        animate={{ rotate: 720, scale: 1.5 }}
        transition={{ duration: 4, ease: 'easeInOut' }}
      />

      {/* Wind Spiral Lines */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute left-1/2 top-1/2 origin-left h-1 bg-gradient-to-r from-purple-400/80 to-transparent"
          style={{
            width: `${300 + i * 50}px`,
            transform: `rotate(${i * 30}deg)`
          }}
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ 
            opacity: [0, 0.8, 0],
            scaleX: [0, 1, 1.5],
            rotate: `${i * 30 + 360}deg`
          }}
          transition={{ 
            duration: 3,
            delay: i * 0.1,
            ease: 'easeOut'
          }}
        />
      ))}

      {/* Debris Blur Elements */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-slate-400 rounded-full"
          initial={{ 
            x: Math.cos(i * 18 * Math.PI / 180) * 200,
            y: Math.sin(i * 18 * Math.PI / 180) * 200,
            opacity: 0.8
          }}
          animate={{ 
            x: Math.cos((i * 18 + 720) * Math.PI / 180) * 600,
            y: Math.sin((i * 18 + 720) * Math.PI / 180) * 600,
            opacity: 0
          }}
          transition={{ 
            duration: 3,
            delay: i * 0.05,
            ease: 'easeIn'
          }}
          style={{
            left: '50%',
            top: '50%',
            filter: 'blur(4px)'
          }}
        />
      ))}

      {/* Zoom Collapse Effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-purple-900/40 to-slate-900/40"
        initial={{ scale: 2, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 4, ease: 'easeIn' }}
      />

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <h2 className="text-4xl font-bold text-purple-200 mb-2">Analyzing Cyclone Risk</h2>
        <p className="text-purple-300">Wind tunnel simulation...</p>
      </motion.div>
    </div>
  );
}
