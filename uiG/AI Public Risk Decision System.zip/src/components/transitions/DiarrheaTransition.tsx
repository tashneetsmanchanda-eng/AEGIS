import { motion } from 'motion/react';

export function DiarrheaTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-emerald-950/30 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Liquid Contamination Flow */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 1000">
        {[...Array(8)].map((_, i) => (
          <motion.path
            key={i}
            d={`
              M ${100 + i * 120} 0
              Q ${120 + i * 120} 250 ${100 + i * 120} 500
              T ${100 + i * 120} 1000
            `}
            stroke={`rgba(16, 185, 129, ${0.3 - i * 0.03})`}
            strokeWidth="40"
            fill="none"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ 
              pathLength: 1,
              opacity: [0, 0.6, 0.4]
            }}
            transition={{ 
              duration: 3,
              delay: i * 0.2,
              ease: 'easeInOut'
            }}
            style={{
              filter: 'blur(10px)'
            }}
          />
        ))}
      </svg>

      {/* Fluid Dynamics Ripples */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute left-1/2 top-1/2 rounded-full border-2 border-emerald-400/40"
          initial={{ 
            width: 0,
            height: 0,
            x: '-50%',
            y: '-50%',
            opacity: 0.8
          }}
          animate={{ 
            width: 600,
            height: 600,
            opacity: 0
          }}
          transition={{ 
            duration: 4,
            delay: i * 0.7,
            ease: 'easeOut',
            repeat: Infinity
          }}
        />
      ))}

      {/* Organic Flow Particles */}
      {[...Array(25)].map((_, i) => {
        const startX = Math.random() * window.innerWidth;
        const startY = Math.random() * 200;
        const endX = startX + (Math.random() - 0.5) * 200;
        
        return (
          <motion.div
            key={i}
            className="absolute w-4 h-4 bg-emerald-400 rounded-full"
            initial={{ 
              x: startX,
              y: startY,
              opacity: 0.7,
              scale: 1
            }}
            animate={{ 
              x: endX,
              y: window.innerHeight + 50,
              opacity: 0,
              scale: 0.5
            }}
            transition={{ 
              duration: 3 + Math.random() * 2,
              delay: i * 0.15,
              ease: 'easeIn'
            }}
            style={{
              filter: 'blur(3px)'
            }}
          />
        );
      })}

      {/* Contamination Gradient Overlay */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-emerald-900/20 to-emerald-900/40"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      />

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <h2 className="text-4xl font-bold text-emerald-200 mb-2">Analyzing Diarrheal Disease Risk</h2>
        <p className="text-emerald-300">Contamination flow modeling...</p>
      </motion.div>
    </div>
  );
}
