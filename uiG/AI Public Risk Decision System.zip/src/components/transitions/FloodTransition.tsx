import { motion } from 'motion/react';

export function FloodTransition() {
  return (
    <div className="absolute inset-0 bg-slate-950 overflow-hidden flex items-center justify-center">
      {/* Rising Water Effect */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-900 via-blue-800 to-blue-700"
        initial={{ height: '0%' }}
        animate={{ height: '100%' }}
        transition={{ duration: 4, ease: 'easeIn' }}
        style={{
          opacity: 0.6
        }}
      />

      {/* Water Ripples */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border-2 border-blue-400"
          initial={{ 
            width: 0, 
            height: 0, 
            opacity: 0.8,
            x: '-50%',
            y: '-50%'
          }}
          animate={{ 
            width: 800, 
            height: 800, 
            opacity: 0,
            x: '-50%',
            y: '-50%'
          }}
          transition={{ 
            duration: 2,
            delay: i * 0.6,
            repeat: Infinity,
            ease: 'easeOut'
          }}
          style={{
            left: '50%',
            top: '50%'
          }}
        />
      ))}

      {/* Reflection Effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-300/10 to-blue-500/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2, delay: 1 }}
      />

      {/* Pressure Distortion */}
      <motion.div
        className="absolute inset-0"
        initial={{ backdropFilter: 'blur(0px)' }}
        animate={{ backdropFilter: 'blur(8px)' }}
        transition={{ duration: 3 }}
      />

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <h2 className="text-4xl font-bold text-blue-200 mb-2">Analyzing Flood Risk</h2>
        <p className="text-blue-300">Rising water simulation...</p>
      </motion.div>
    </div>
  );
}
