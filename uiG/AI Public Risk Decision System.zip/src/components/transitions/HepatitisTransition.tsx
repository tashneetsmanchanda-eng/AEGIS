import { motion } from 'motion/react';

export function HepatitisTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-red-950/30 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Bloodstream Tunnel Effect */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 0%, rgba(239, 68, 68, 0.2) 50%, rgba(127, 29, 29, 0.4) 100%)'
        }}
        initial={{ scale: 2 }}
        animate={{ scale: 1 }}
        transition={{ duration: 4, ease: 'easeOut' }}
      />

      {/* Tunnel Rings */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute left-1/2 top-1/2 rounded-full border-2 border-red-500/30"
          initial={{ 
            width: 1200,
            height: 1200,
            x: '-50%',
            y: '-50%',
            opacity: 0
          }}
          animate={{ 
            width: 200,
            height: 200,
            opacity: [0, 0.6, 0]
          }}
          transition={{ 
            duration: 3,
            delay: i * 0.4,
            ease: 'easeIn',
            repeat: Infinity
          }}
        />
      ))}

      {/* Viral Forms Drifting */}
      {[...Array(30)].map((_, i) => {
        const angle = Math.random() * 360;
        const distance = 100 + Math.random() * 400;
        const size = 15 + Math.random() * 25;
        
        return (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: size,
              height: size,
              background: 'radial-gradient(circle, rgba(239, 68, 68, 0.8), rgba(185, 28, 28, 0.4))',
              left: '50%',
              top: '50%'
            }}
            initial={{ 
              x: Math.cos(angle * Math.PI / 180) * 200 - size / 2,
              y: Math.sin(angle * Math.PI / 180) * 200 - size / 2,
              opacity: 0.8,
              scale: 1
            }}
            animate={{ 
              x: Math.cos(angle * Math.PI / 180) * distance - size / 2,
              y: Math.sin(angle * Math.PI / 180) * distance - size / 2,
              opacity: [0.8, 0.4, 0],
              scale: [1, 1.2, 0.8]
            }}
            transition={{ 
              duration: 4 + Math.random() * 2,
              delay: i * 0.1,
              ease: 'easeOut'
            }}
            style={{
              filter: 'blur(3px)'
            }}
          />
        );
      })}

      {/* Heartbeat-synced Pulses */}
      <motion.div
        className="absolute inset-0 bg-red-600/10"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.3, 0, 0.3, 0] }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          times: [0, 0.1, 0.2, 0.3, 0.4]
        }}
      />

      {/* Blood Cell Particles */}
      {[...Array(40)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full bg-red-400"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0.5
          }}
          animate={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: [0.5, 0.8, 0.3]
          }}
          transition={{ 
            duration: 6 + Math.random() * 4,
            repeat: Infinity,
            ease: 'linear'
          }}
          style={{
            filter: 'blur(1px)'
          }}
        />
      ))}

      {/* Vignette Effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-red-950/40" />

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <h2 className="text-4xl font-bold text-red-200 mb-2">Analyzing Hepatitis Risk</h2>
        <p className="text-red-300">Bloodstream viral analysis...</p>
      </motion.div>
    </div>
  );
}
