import { motion } from 'motion/react';

export function LeptospirosisTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-800 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Heavy Rainfall Effect */}
      {[...Array(100)].map((_, i) => {
        const x = Math.random() * window.innerWidth;
        const delay = Math.random() * 2;
        const duration = 1 + Math.random() * 1;
        
        return (
          <motion.div
            key={i}
            className="absolute w-0.5 bg-gradient-to-b from-blue-300/80 to-transparent"
            style={{
              height: 40 + Math.random() * 40,
              left: x,
              top: -50
            }}
            initial={{ y: -50, opacity: 0.8 }}
            animate={{ 
              y: window.innerHeight + 50,
              opacity: [0.8, 0.4, 0]
            }}
            transition={{ 
              duration: duration,
              delay: delay,
              repeat: Infinity,
              ease: 'linear'
            }}
          />
        );
      })}

      {/* Contaminated Puddle Spread */}
      {[...Array(8)].map((_, i) => {
        const x = (i % 4) * (window.innerWidth / 4) + Math.random() * 100;
        const y = Math.floor(i / 4) * (window.innerHeight / 2) + Math.random() * 100;
        
        return (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              left: x,
              top: y,
              background: 'radial-gradient(circle, rgba(99, 102, 241, 0.3), rgba(99, 102, 241, 0.1), transparent)'
            }}
            initial={{ width: 0, height: 0, opacity: 0 }}
            animate={{ 
              width: 150 + Math.random() * 100,
              height: 150 + Math.random() * 100,
              opacity: [0, 0.6, 0.4]
            }}
            transition={{ 
              duration: 3,
              delay: i * 0.4,
              ease: 'easeOut'
            }}
          />
        );
      })}

      {/* Ground Water Seepage */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-indigo-950/60 via-indigo-900/30 to-transparent"
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 3, ease: 'easeOut' }}
      />

      {/* Wet Atmosphere Particles */}
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-slate-400 rounded-full"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0.4
          }}
          animate={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: [0.4, 0.7, 0.3]
          }}
          transition={{ 
            duration: 8 + Math.random() * 4,
            repeat: Infinity,
            ease: 'linear'
          }}
          style={{
            filter: 'blur(2px)'
          }}
        />
      ))}

      {/* Earthy Color Overlay */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-amber-950/10 to-amber-950/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      />

      {/* Rain Ripples */}
      {[...Array(12)].map((_, i) => {
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        
        return (
          <motion.div
            key={i}
            className="absolute rounded-full border border-indigo-400/40"
            style={{ left: x, top: y }}
            initial={{ width: 0, height: 0, opacity: 0.6 }}
            animate={{ 
              width: 80,
              height: 80,
              opacity: 0
            }}
            transition={{ 
              duration: 1.5,
              delay: i * 0.3,
              repeat: Infinity,
              ease: 'easeOut'
            }}
          />
        );
      })}

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <h2 className="text-4xl font-bold text-indigo-200 mb-2">Analyzing Leptospirosis Risk</h2>
        <p className="text-indigo-300">Rainfall contamination modeling...</p>
      </motion.div>
    </div>
  );
}
