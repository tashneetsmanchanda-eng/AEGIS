import { motion } from 'motion/react';

export function RespiratoryTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-orange-950/40 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Breathing Fog Pulses */}
      <motion.div
        className="absolute inset-0 bg-gradient-radial from-orange-400/20 via-orange-600/10 to-transparent"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ 
          scale: [0.8, 1.2, 0.8],
          opacity: [0, 0.6, 0]
        }}
        transition={{ 
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
        style={{
          filter: 'blur(60px)'
        }}
      />

      {/* Airflow Waves */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.3, 0] }}
          transition={{ 
            duration: 4,
            delay: i * 0.6,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        >
          <svg className="w-full h-full" viewBox="0 0 1000 1000">
            <motion.path
              d={`M 0 ${500 + i * 30} Q 250 ${450 + i * 30} 500 ${500 + i * 30} T 1000 ${500 + i * 30}`}
              stroke="rgba(251, 146, 60, 0.4)"
              strokeWidth="2"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ 
                duration: 3,
                delay: i * 0.6,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
          </svg>
        </motion.div>
      ))}

      {/* Lung-like Rhythm Container */}
      <motion.div
        className="absolute w-96 h-96 rounded-full border-4 border-orange-500/30"
        initial={{ scale: 0.6 }}
        animate={{ 
          scale: [0.6, 1, 0.6],
        }}
        transition={{ 
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
        style={{
          filter: 'blur(4px)'
        }}
      />

      <motion.div
        className="absolute w-80 h-80 rounded-full border-4 border-orange-400/40"
        initial={{ scale: 0.7 }}
        animate={{ 
          scale: [0.7, 0.9, 0.7],
        }}
        transition={{ 
          duration: 4,
          delay: 0.5,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
        style={{
          filter: 'blur(4px)'
        }}
      />

      {/* Particle Pollution */}
      {[...Array(40)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-orange-300 rounded-full"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0.6
          }}
          animate={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: [0.6, 0.2, 0.6]
          }}
          transition={{ 
            duration: 5 + Math.random() * 3,
            repeat: Infinity,
            ease: 'linear'
          }}
          style={{
            filter: 'blur(1px)'
          }}
        />
      ))}

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <h2 className="text-4xl font-bold text-orange-200 mb-2">Analyzing Respiratory Risk</h2>
        <p className="text-orange-300">Airflow quality assessment...</p>
      </motion.div>
    </div>
  );
}
