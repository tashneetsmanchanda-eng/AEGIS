import { motion } from 'motion/react';

export function TsunamiTransition() {
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-cyan-950 to-slate-950 overflow-hidden flex items-center justify-center">
      {/* Vertical Wall of Water */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/60 to-transparent"
        initial={{ x: '-100%', scaleY: 0.3 }}
        animate={{ x: '100%', scaleY: 1 }}
        transition={{ duration: 4, ease: 'easeInOut' }}
        style={{
          filter: 'blur(20px)'
        }}
      />

      {/* Underwater Pressure Effect */}
      <motion.div
        className="absolute inset-0"
        initial={{ 
          background: 'radial-gradient(circle at 50% 120%, transparent 0%, rgba(6, 182, 212, 0) 100%)'
        }}
        animate={{ 
          background: 'radial-gradient(circle at 50% 50%, transparent 0%, rgba(6, 182, 212, 0.4) 100%)'
        }}
        transition={{ duration: 3 }}
      />

      {/* Warp Distortion Bands */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute left-0 right-0 h-16 bg-cyan-400/10"
          style={{
            top: `${i * 12.5}%`,
            filter: 'blur(10px)'
          }}
          initial={{ scaleX: 0.5, opacity: 0 }}
          animate={{ 
            scaleX: [0.5, 1.2, 0.8, 1],
            opacity: [0, 0.6, 0.3, 0]
          }}
          transition={{ 
            duration: 3,
            delay: i * 0.2,
            ease: 'easeInOut'
          }}
        />
      ))}

      {/* Heavy Water Particles */}
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 bg-cyan-300 rounded-full"
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: -50,
            opacity: 0.8
          }}
          animate={{ 
            y: window.innerHeight + 50,
            opacity: 0
          }}
          transition={{ 
            duration: 2 + Math.random() * 2,
            delay: i * 0.1,
            ease: 'easeIn'
          }}
          style={{
            filter: 'blur(2px)'
          }}
        />
      ))}

      {/* Slow Dread Vignette */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-b from-slate-950/50 via-transparent to-slate-950/50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      />

      {/* Text */}
      <motion.div
        className="relative z-10 text-center"
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 1 }}
      >
        <h2 className="text-4xl font-bold text-cyan-200 mb-2">Analyzing Tsunami Risk</h2>
        <p className="text-cyan-300">Pressure wave simulation...</p>
      </motion.div>
    </div>
  );
}
